export const EVENTS_DATA =  [
	{
		"event_id" : 1,
		"event_name" : "INDIAWOOD 2022",
		"event_count" : 62681
	},
	{
		"event_id" : 2,
		"event_name" : "INDIA MATTRESSTECH + UPHOLSTERY SUPPLIES EXPO (IME) 2022",
		"event_count" : 5101
	},
	{
		"event_id" : 3,
		"event_name" : "HPCI INDIA",
		"event_count" : 3375
	},
	{
		"event_id" : 4,
		"event_name" : "PAINTINDIA 2022",
		"event_count" : 15793
	},
	{
		"event_id" : 5,
		"event_name" : "Wood in Architecture & Design",
		"event_count" : 263
	},
	{
		"event_id" : 7,
		"event_name" : "BROADCAST INDIA 2022",
		"event_count" : 17182
	},
	{
		"event_id" : 8,
		"event_name" : "SCAT India 2022",
		"event_count" : 8784
	},
	{
		"event_id" : 9,
		"event_name" : "BIOFACH India 2022",
		"event_count" : 3695
	},
	{
		"event_id" : 10,
		"event_name" : "MILLETS INDIA 2022",
		"event_count" : 371
	},
	{
		"event_id" : 11,
		"event_name" : "Natural Expo India",
		"event_count" : 78
	},
	{
		"event_id" : 6,
		"event_name" : "Index",
		"event_count" : 109
	},
	{
		"event_id" : 13,
		"event_name" : "Index 2022, Mumbai",
		"event_count" : 37
	},
	{
		"event_id" : 21,
		"event_name" : "FSBI 2023",
		"event_count" : 1835
	},
	{
		"event_id" : 12,
		"event_name" : "Kevent_ids India 2022",
		"event_count" : 32
	},
	{
		"event_id" : 22,
		"event_name" : "DELHIWOOD",
		"event_count" : 23842
	},
	{
		"event_id" : 23,
		"event_name" : "ALUCAST",
		"event_count" : 5411
	},
	{
		"event_id" : 25,
		"event_name" : "HPCI India 2023",
		"event_count" : 4927
	},
	{
		"event_id" : 24,
		"event_name" : "BIOFACH India 2023",
		"event_count" : 351
	},
	{
		"event_id" : 26,
		"event_name" : "IME 2023",
		"event_count" : 5457
	},
	{
		"event_id" : 27,
		"event_name" : "PAINT INDIA 2023",
		"event_count" : 5631
	},
	{
		"event_id" : 28,
		"event_name" : "MILLETS INDIA 2023",
		"event_count" : 91
	},
	{
		"event_id" : 29,
		"event_name" : "ABIS - Industry Connect",
		"event_count" : 322
	},
	{
		"event_id" : 31,
		"event_name" : "Conference- FSBI1",
		"event_count" : 100
	},
	{
		"event_id" : 32,
		"event_name" : "Wood in Architecture & Design 2023",
		"event_count" : 205
	},
	{
		"event_id" : 33,
		"event_name" : "Index 2023 - Mumbai",
		"event_count" : 6
	},
	{
		"event_id" : 37,
		"event_name" : "HPCI 2024",
		"event_count" : 1
	},
	{
		"event_id" : 34,
		"event_name" : "IME 2024",
		"event_count" : 49
	},
	{
		"event_id" : 35,
		"event_name" : "Broadcast India 2023",
		"event_count" : 528
	},
	{
		"event_id" : 36,
		"event_name" : "SCAT India 2023",
		"event_count" : 134
	},
	{
		"event_id" : 38,
		"event_name" : "PAINTINDIA 2024",
		"event_count" : 1
	},
	{
		"event_id" : 39,
		"event_name" : "Indiawood 2024",
		"event_count" : 1
	},
	{
		"event_id" : 44,
		"event_name" : "Biofach India 2023 conference",
		"event_count" : 1
	},
	{
		"event_id" : 46,
		"event_name" : "Test Event",
		"event_count" : 8
	},
	{
		"event_id" : 47,
		"event_name" : "Content India Show 2023",
		"event_count" : 7
	},
	{
		"event_id" : 43,
		"event_name" : "Kevent_ids India 2023",
		"event_count" : 3
	}
]
